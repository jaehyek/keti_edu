#include "employee.h"

Employee::Employee(int id, string ename, int salary)
{
	this->id = id;
	this->ename = ename;
	this->salary = salary;
	cout<<"Create Employee"<<endl;
}

Employee::~Employee()
{
	cout<<"Destroy Employee"<<endl;
}

void Employee::Show()
{
	cout<<"ID : "<<this->id<<endl;
	cout<<"Name : "<<this->ename<<endl;
	cout<<"Salary : "<<this->salary<<endl;
}

bool Employee::IsDaily()
{
	return EMPLOYEE;
}

int Employee::GetSalary()
{
	return this->salary;
}

string Employee::GetName()
{
	return ename;
}

void Employee::SetSalary(int salary)
{
	if(salary > 0 && salary <10000000)
	{
		this->salary = salary;
	}
	else
	{
		cout<<"Out of range"<<endl;
	}
}

DailyEmployee::DailyEmployee(int id, string ename, int salary, int wd) : Employee(id, ename, salary)
{
	this->id = id;
	this->ename = ename;
	this->salary = salary;
	this->workingDay = wd;
	cout<<"Create DailyEmployee"<<endl;
}

DailyEmployee::~DailyEmployee()
{
	cout<<"Destroy DailyEmployee"<<endl;
}

void DailyEmployee::Show()
{
	cout<<"ID : "<<this->id<<endl;
	cout<<"Name : "<<this->ename<<endl;
	cout<<"Salary : "<<this->salary<<" * "<<this->workingDay<<" = "<<this->salary*this->workingDay<<endl;
}
bool DailyEmployee::IsDaily()
{
	return DAILYEMPLOYEE;
}

EmpMgr::EmpMgr()
{
	index = 0;
	d_index = 0;
	cout<<"Create Employee Manager"<<endl;
}

EmpMgr::~EmpMgr()
{
	em.clear();
	cout<<"Destroy Employee Manager"<<endl;
}

	

void EmpMgr::inputEmployee()
{
	int select;
	int id;
	string ename;
	int salary,wd;
	
	cout<<"1. Employee / 2. DailyEmployee : ";
	cin>>select;
	
	if(select == 1)
	{
		cout<<"Name : ";
		cin>>ename;

		if(!cin.good())
		{
			cout<<"Error"<<endl;
		}
		cin.clear();
		cin.ignore(4,'\n');

		cout<<"Salary : ";
		cin>>salary;

		if(!cin.good())
		{
			cout<<"Error"<<endl;
		}	vector<Employee *>::iterator it;
		cin.clear();
		cin.ignore(4,'\n');

		index++;
		id = 1000000+index;

		Employee *temp = new Employee(id,ename,salary);
		em.push_back(temp);
	}
	else if(select == 2)
	{
		cout<<"Name : ";
		cin>>ename;

		if(!cin.good())
		{
			cout<<"Error"<<endl;
		}
		cin.clear();
		cin.ignore(4,'\n');

		cout<<"Salary : ";
		cin>>salary;

		if(!cin.good())
		{
			cout<<"Error"<<endl;
		}
		cin.clear();
		cin.ignore(4,'\n');

		cout<<"Working Day : ";
		cin>>wd;

		if(!cin.good())
		{
			cout<<"Error"<<endl;
		}
		cin.clear();
		cin.ignore(4,'\n');

		d_index++;
		id = 2000000+d_index;

		DailyEmployee *temp = new DailyEmployee(id,ename,salary,wd);
		em.push_back(temp);
		delete temp;
	}		
}

void EmpMgr::modifyEmpoyee()
{
	string ename;
	int salary;

	vector<Employee *>::iterator it;

	cout<<"Name : ";
	cin>>ename;


	if(!cin.good())
	{
 		return;
	}
	cin.clear();
	cin.ignore(4,'\n');



	for(it = em.begin(); it!= em.end(); it++)
	{
		if((*it)->GetName() == ename)
		{
			cout<<"Salary : ";
			cin>>salary;

			if(!cin.good())
			{
				cout<<"Error"<<endl;
			}
			cin.clear();
			cin.ignore(4,'\n');

			(*it)->SetSalary(salary);
		}

	}
}
	

void EmpMgr::showAll()
{
	vector<Employee *>::iterator it;

	for(it = em.begin(); it!= em.end(); it++)
	{
		if((*it)->IsDaily() == EMPLOYEE)
		{
			cout<<"--EMPLOYEE"<<endl;
			(*it)->Show();
		}
		if((*it)->IsDaily() == DAILYEMPLOYEE)
		{
			cout<<"--DAILYEMPLOYEE"<<endl;
			(*it)->Show();
		}
	}
}
