#include <iostream>
#include "employee.h"
using namespace std;

int main(void)
{
//	system("clear");

	int select;
	
	EmpMgr em;

	do
	{	
		cout<<"\n--Select Menu--\n";
		cout<<"1. Input Employee \n";
		cout<<"2. Modify Salary \n";
		cout<<"3. View All Employee \n";
		cout<<"4. Exit \n";
		cout<<"\nInput Number : ";

		cin>>select;
		if(!cin.good())
		{
			cout<<"Error"<<endl;
			break;
		}
		cin.clear();
		cin.ignore(4,'\n');

		if(select == 1)
		{
			em.inputEmployee();
		}		
		else if(select == 2)
		{
			em.modifyEmpoyee();
		}
		else if(select == 3)
		{
			em.showAll();
		}
		else if(select == 4)
		{
			break;
		}
		else
		{
			cout<<"\nRetry\n";
		}
	}while(1);

	return 0;
}

