#include <iostream>
#include <cstring>
#include <vector>

using namespace std;

class Employee
{
protected:
	int id;
	string ename;
	int salary;
public:
	Employee(int, string, int);
	virtual ~Employee();

	virtual void Show();
	virtual bool IsDaily();

	int GetSalary();
	void SetSalary(int);
	string GetName();
};

class DailyEmployee : public Employee
{
private:
	int workingDay;
public:
	DailyEmployee(int, string, int, int);
	virtual ~DailyEmployee();

	virtual void Show();
	virtual bool IsDaily();
};

class EmpMgr
{
private:
	vector<Employee *> em;
	int index;
	int d_index;
public:

	EmpMgr();
	~EmpMgr();

	void inputEmployee();
	void modifyEmpoyee();
	void showAll();
};

enum EMP{EMPLOYEE,DAILYEMPLOYEE};
