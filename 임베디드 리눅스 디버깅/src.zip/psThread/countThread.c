#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

void * thread_function(void *);
void idxReset();

int commonCounter[10] = { 1, 6, 3, 7, 9, 2, 4, 5, 8, 0 };
int idx=0;
pthread_mutex_t mutexid;

int main(void)
{
	pthread_t tid;
	void *thread_result;

	if(pthread_mutex_init(&mutexid, NULL) !=0 ) {
		perror("pthread_mutex_init");
		exit(1);
	}

	if(pthread_create(&tid, NULL, thread_function,  "thread1")!=0) {
		perror("pthread_create");
		exit(1);
	}

	if(pthread_join(tid, &thread_result)!=0) {
		perror("pthread_join");
		exit(1);
	}

	printf(" thread result : %s\n", (char *) thread_result);

	int i;
	for(i=0; i<10; i++)
		printf("commonCounter[%d] = %d\n", i, commonCounter[i]);

	return 0;
}

void idxReset()
{
	pthread_mutex_lock(&mutexid);
	idx=0;
	pthread_mutex_unlock(&mutexid);
}


void * thread_function(void * arg)
{
	int temp;
	int i, j;
	char buffer[80];

	printf("thread_function called\n");
	for(i=0; i<20; i++) {
		pthread_mutex_lock(&mutexid);
		if(idx==10) {
			idxReset();
		}
		sprintf(buffer, "%s : commonCounter : from %d to ", (char*)arg, commonCounter[idx]);
		write(1, buffer, strlen(buffer));

		temp=commonCounter[idx];

// delay
//		for(j=0; j<500000; j++);

		commonCounter[idx]=temp+1;

		sprintf(buffer, " %d\n", commonCounter[idx]);
		write(1, buffer, strlen(buffer));

//		for(j=0; j<500000; j++);
		idx++;
		pthread_mutex_unlock(&mutexid);

	}
	pthread_exit("thread end");
}
