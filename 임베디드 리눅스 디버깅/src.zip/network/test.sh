#!/bin/bash
if [ $# -ne 1 ]
then
	echo "$0 port#"
	exit 1
fi

[ -x ./down ] &&  su root -c "./down ; rm down" 
telnet localhost $1
