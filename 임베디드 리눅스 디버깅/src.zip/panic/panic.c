#include <linux/module.h>
#include <linux/init.h>

static int __init panic_init(void)
{
    printk("panic_init called\n");
	panic("panic has been called\n");
    return 0;
}

module_init(panic_init);

