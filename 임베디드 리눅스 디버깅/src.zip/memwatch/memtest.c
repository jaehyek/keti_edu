#include <stdlib.h>
#include <stdio.h>
#include "memwatch.h"

#define MAX 10

int main()
{
	char* srcStr = (char *) calloc(sizeof(char), MAX);
	char* destStr = (char*) calloc(sizeof(char),MAX-1);

	int i;

	for(i=0;i<=MAX; i++)
		srcStr[i]='A'+i;

	destStr = srcStr;

	free(srcStr);
	free(destStr);

	return 0;
	
}
