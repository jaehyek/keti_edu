#include <iostream>
using namespace std;

int main()
{
	int *mainPtr =  new  int;

	if(*mainPtr==100)
		cout << "100" << endl;

	delete mainPtr;

	return 0;	
}
