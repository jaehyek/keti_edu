#include <iostream>
using namespace std;

int*memAlloc(int);
void setFree(int*);

int main()
{
	int *mainPtr;

	mainPtr = memAlloc(sizeof(int));

	*mainPtr=100;

	if(*mainPtr==100)
		cout << "100" << endl;

	setFree(mainPtr);
	delete mainPtr;

	return 0;	
}

int* memAlloc(int size)
{
	return new int;
}

void setFree(int* mainPtr) 
{
	delete mainPtr;
}
