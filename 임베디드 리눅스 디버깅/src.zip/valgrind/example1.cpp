#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	char* ptr = new char[80];

	cout << "Input>> " ;

	cin >> ptr;

	cout << ptr << endl;

	return 0;	
	
}
