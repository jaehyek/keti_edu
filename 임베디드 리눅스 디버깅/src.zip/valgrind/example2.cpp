#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	int* ptr = new int[10];

	for(int i=0; i<=10; i++) {
		ptr[i] = i+ 1;
	}

	for(int i=0; i<=10; i++) {
		cout << ptr[i] << endl;
	}

	delete[] ptr;
	return 0;	
	
}
