#include <iostream>
using namespace std;

int main()
{
	int *mainPtr =  new  int;

	*mainPtr=100;

	if(*mainPtr==100)
		cout << "100" << endl;

	delete mainPtr;

	*mainPtr = 200;

	return 0;	
}
