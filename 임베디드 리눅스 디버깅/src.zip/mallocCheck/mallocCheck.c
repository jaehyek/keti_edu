#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	char* p1 = (char*) malloc(sizeof(char)*10);
	p1 = "Beauty";
	char* p2 = (char*) malloc(sizeof(char)*10);
	p2 = p1;

	free(p2);
	free(p1);
	return 0;
}
