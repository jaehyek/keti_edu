#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void* inc_thread(void* arg);
void* dec_thread(void* arg);

int commonCount=0;

int main()
{
	pthread_t tid[2];

	if(pthread_create(&tid[0], NULL, inc_thread, NULL)!=0) {
		perror("pthread_create");
		exit(1);
	}
	if(pthread_create(&tid[1], NULL, dec_thread, NULL)!=0) {
		perror("pthread_create");
		exit(1);
	}

	pthread_join(tid[0], NULL);
	pthread_join(tid[1], NULL);

	return 0;
}

void* inc_thread(void* arg)
{
	int i, j, temp;

	for(i=0; i<40; i++) {
		temp = commonCount;
		for(j=0;j<10000000; j++);
		commonCount = temp + 1;
		printf("thread1 : %d\n", commonCount);
	}
	pthread_exit(NULL);
}

void* dec_thread(void* arg)
{
	int i, j, temp;

	for(i=0; i<30; i++) {
		temp = commonCount;
		for(j=0;j<12000000; j++);
		commonCount = temp - 1;
		printf("thread2 : %d\n", commonCount);
	}
	pthread_exit(NULL);
}

