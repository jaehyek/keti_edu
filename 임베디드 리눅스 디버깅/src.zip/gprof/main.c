#include <stdio.h>
#include <stdlib.h>
#include "isprime.h"
int main()
{
	int i;
	int c=0;

	for(i=2; i<50000; i++)
		if(isPrime(i)) {
			c++;
			if(c%10==0) {
				printf("%d\n",i);
				c=0;
			} else {
				printf("%d\t", i);
			}

		}
	printf("\n");

	return 0;
}


