#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct layout {
	struct layout *ebp;
	void* ret;
} layout;

void backtraceByGcc(void)
{
	layout* ebp = __builtin_frame_address(0);
	while(ebp) {
		printf("0x%08x\n", ebp->ret);
		ebp = ebp->ebp;
	}
}
