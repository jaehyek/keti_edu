#include <stdio.h>

void delayFunc() 
{
	int i;
	for(i=0; i<2000000; i++);
}

void func1()
{
	int i;
	for(i=0; i<1000; i++)
		delayFunc();
}

void func2()
{
	int i;
	for(i=0; i<4000; i++)
		delayFunc();
}

int main()
{
	func1();
	func2();
}
