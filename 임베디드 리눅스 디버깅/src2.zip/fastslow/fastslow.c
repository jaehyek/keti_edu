#include <stdio.h>

int fastMultiply(int m, int n)
{
	return m*n;
}

int slowMultiply(int m, int n)
{
	int i, sum=0;
	for(i=1; i<=n; i++)
		sum += m;
	return sum;
}


int main()
{
	int i,j;

	for(i=1; i<2000; i++)
		for(j=1;j<500; j++) {
			printf("%d * %d = %d\n", i, j, fastMultiply(i,j));
			printf("%d * %d = %d\n", i, j, slowMultiply(i,j));
		}
				
}
